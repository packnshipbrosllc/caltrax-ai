# 🔐 Netlify Environment Variables Setup

## 🚀 **CRITICAL: Set These Environment Variables in Netlify**

After deploying to Netlify, you MUST set these environment variables in your Netlify dashboard:

### **1. Go to Netlify Dashboard**
1. Visit [app.netlify.com](https://app.netlify.com)
2. Select your CalTrax site
3. Go to **Site Settings** → **Environment Variables**
4. Click **"Add Variable"** for each one below

### **2. Required Environment Variables**

#### **Supabase Configuration**
```
NEXT_PUBLIC_SUPABASE_URL = https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJ...your_anon_key_here
```

#### **Clerk Authentication**
```
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY = pk_test_ZXRoaWNhbC1hc3AtOTcuY2xlcmsuYWNjb3VudHMuZGV2JA
CLERK_SECRET_KEY = sk_test_EUNrplX49iTrzOH9fbDG6wwqRW6kW3wibwmGYecDKV
```

#### **Stripe Payment Processing**
```
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_live_51S843W2LmuiKVnPdDqRZB6VjLk2mflxRjmcGJEGFgeYBiD1qS8pihppJdJNwGVnU7r1BNEl1gmqJ0qtOMq67dNsq00hfphXU8o
STRIPE_SECRET_KEY = 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
```

#### **OpenAI API (SECURE)**
```
OPENAI_API_KEY = sk-proj-your_new_openai_api_key_here
```

#### **App Configuration**
```
NEXT_PUBLIC_APP_URL = https://caltrax.ai
```

### **3. How to Get Your Keys**

#### **Supabase Keys:**
1. Go to [supabase.com/dashboard](https://supabase.com/dashboard)
2. Select your CalTrax project
3. Go to **Settings** → **API**
4. Copy **Project URL** and **Anon Key**

#### **OpenAI API Key:**
1. Go to [platform.openai.com](https://platform.openai.com)
2. Go to **API Keys**
3. Click **"Create new secret key"**
4. Copy the key (starts with `sk-proj-`)

### **4. Security Notes**
- ✅ **Never commit API keys to code**
- ✅ **Use different keys for development vs production**
- ✅ **Rotate keys regularly**
- ✅ **Monitor API usage**

### **5. After Setting Variables**
1. **Redeploy** your site (Netlify will automatically rebuild)
2. **Test** all features to ensure they work
3. **Monitor** the Netlify function logs for any errors

## 🚨 **IMPORTANT**
Without these environment variables, your app will not work in production!
