# CalTrax Setup Guide

This guide will help you set up your CalTrax app with all your existing settings imported.

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
npm run setup

# 3. Edit .env.local with your actual credentials
# 4. Set up database
npm run setup-db

# 5. Start development server
npm run dev

# 6. Deploy to production
npm run deploy
```

## 📋 Prerequisites

Before you start, make sure you have:
- [ ] Node.js 18+ installed
- [ ] Your existing Stripe account credentials
- [ ] Your existing Supabase project (or create a new one)
- [ ] Your Clerk account credentials
- [ ] Your OpenAI API key

## 🔧 Step-by-Step Setup

### 1. Environment Variables

Run the setup script to create your environment file:

```bash
npm run setup
```

This creates `.env.local` with your existing Stripe configuration. You'll need to add:

#### Supabase Credentials
1. Go to [supabase.com/dashboard](https://supabase.com/dashboard)
2. Select your project (or create a new one)
3. Go to Settings > API
4. Copy your Project URL and Anon Key
5. Add them to `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
   ```

#### Stripe Credentials (Already Configured)
Your existing Stripe settings are already imported:
- Publishable Key: `pk_live_51S843W2LmuiKVnPdDqRZB6VjLk2mflxRjmcGJEGFgeYBiD1qS8pihppJdJNwGVnU7r1BNEl1gmqJ0qtOMq67dNsq00hfphXU8o`
- Monthly Plan: `price_1S84cT2LmuiKVnPd3NXruhvk` ($5.00/month)
- Yearly Plan: `price_1S84dS2LmuiKVnPdj6UCRzsN` ($30.00/year)

You just need to add your Stripe secret key to `.env.local`:
```
STRIPE_SECRET_KEY=sk_live_your_secret_key_here
```

#### Clerk Credentials
1. Go to [dashboard.clerk.com](https://dashboard.clerk.com)
2. Create a new application or use existing
3. Copy your publishable and secret keys
4. Add them to `.env.local`

#### OpenAI API Key
1. Go to [platform.openai.com](https://platform.openai.com)
2. Create an API key
3. Add it to `.env.local`:
   ```
   OPENAI_API_KEY=sk-your_openai_api_key_here
   ```

### 2. Database Setup

Run the database setup script:

```bash
npm run setup-db
```

This creates the database schema. Then:

1. Go to your Supabase dashboard
2. Go to SQL Editor
3. Copy and paste the contents of `supabase/schema.sql`
4. Run the SQL to create your tables

### 3. Test Locally

Start the development server:

```bash
npm run dev
```

Visit `http://localhost:3000` to test your app.

### 4. Deploy to Production

Deploy to Vercel:

```bash
npm run deploy
```

This will:
- Build your app
- Deploy to Vercel
- Open your browser to complete setup

## 🎯 Features Included

Your app now includes:

- ✅ **AI Vision Food Analysis** - Point camera at food for instant nutrition
- ✅ **Stripe Payment Processing** - Your existing $5/month and $30/year plans
- ✅ **User Authentication** - Modern auth with Clerk
- ✅ **Macro Tracking** - Full calorie and macro tracking
- ✅ **Food Database** - Searchable food database
- ✅ **Responsive Design** - Beautiful dark theme
- ✅ **Database Persistence** - Real data storage with Supabase

## 🔗 Your Existing Settings Imported

- **Stripe Publishable Key**: `pk_live_51S843W2LmuiKVnPdDqRZB6VjLk2mflxRjmcGJEGFgeYBiD1qS8pihppJdJNwGVnU7r1BNEl1gmqJ0qtOMq67dNsq00hfphXU8o`
- **Monthly Plan**: `price_1S84cT2LmuiKVnPd3NXruhvk` ($5.00/month)
- **Yearly Plan**: `price_1S84dS2LmuiKVnPdj6UCRzsN` ($30.00/year)
- **Trial Period**: 3 days free trial
- **Pricing**: Updated to match your existing $5/month and $30/year pricing

## 🚨 Important Notes

1. **Domain**: Update `NEXT_PUBLIC_APP_URL` in `.env.local` to your actual domain
2. **Webhooks**: Set up Stripe webhooks pointing to your production URL
3. **CORS**: Make sure your domain is added to Clerk's allowed origins
4. **Testing**: Test all payment flows before going live

## 🆘 Troubleshooting

### Build Errors
```bash
npm run lint:fix
```

### Database Connection Issues
- Check your Supabase credentials
- Make sure the database schema is created
- Check Row Level Security policies

### Payment Issues
- Verify your Stripe keys are correct
- Check webhook endpoints
- Test with Stripe test mode first

## 🎉 You're Ready!

Once you complete these steps, your CalTrax app will be:
- ✅ Fully functional
- ✅ Using your existing Stripe settings
- ✅ Connected to a real database
- ✅ Ready for production
- ✅ Ready to start running ads!

Need help? Check the console logs or contact support.
