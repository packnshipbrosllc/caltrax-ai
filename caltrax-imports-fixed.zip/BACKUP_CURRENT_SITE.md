# 🔄 CalTrax Site Backup Guide

## 📋 **Pre-Update Backup Checklist**

Before updating your Netlify site, let's create a complete backup:

### **Step 1: Download Current Site Files**
1. Go to your Netlify dashboard: https://app.netlify.com
2. Select your CalTrax site
3. Go to **Deploys** tab
4. Click on the **latest deployment**
5. Click **"Download deploy"** button
6. Save as `caltrax-backup-$(date).zip`

### **Step 2: Export Environment Variables**
1. Go to **Site Settings** → **Environment Variables**
2. Take a screenshot of all variables
3. Or copy each variable to a text file:

```
# Current Environment Variables Backup
NEXT_PUBLIC_SUPABASE_URL = [your current value]
NEXT_PUBLIC_SUPABASE_ANON_KEY = [your current value]
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = [your current value]
STRIPE_SECRET_KEY = [your current value]
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY = [your current value]
CLERK_SECRET_KEY = [your current value]
OPENAI_API_KEY = [your current value]
NEXT_PUBLIC_APP_URL = [your current value]
```

### **Step 3: Document Current Settings**
- **Domain**: caltrax.ai
- **Build settings**: [Note any custom build commands]
- **Redirects**: [Note any custom redirects]
- **Functions**: [Note any custom Netlify functions]

### **Step 4: Test Current Site**
Before updating, test these features:
- [ ] User sign-up/sign-in
- [ ] Payment processing
- [ ] Food tracking
- [ ] AI features
- [ ] All pages load correctly

## 🚨 **Emergency Rollback Plan**

If something goes wrong after the update:

### **Quick Rollback Steps:**
1. Go to **Deploys** tab
2. Find the **previous working deployment**
3. Click **"Restore"** button
4. Your site will revert to the previous version

### **Full Restore Steps:**
1. Delete current site
2. Create new site from backup zip
3. Re-add environment variables
4. Update domain settings

## ✅ **Backup Complete Checklist**

- [ ] Downloaded current site files
- [ ] Exported environment variables
- [ ] Documented current settings
- [ ] Tested current functionality
- [ ] Created rollback plan

## 🚀 **Ready to Update!**

Once backup is complete, you can safely:
1. Drag and drop `caltrax-production-ready.zip`
2. Monitor the deployment
3. Test new features
4. Rollback if needed

**Your site is now safely backed up!**
