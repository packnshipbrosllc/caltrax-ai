# 🚀 Git-based Deployment Guide

If ZIP upload continues to fail, here's how to deploy via Git:

## **Step 1: Initialize Git Repository**
```bash
cd /Users/johnjohn/Downloads/caltrax-v2
git init
git add .
git commit -m "Initial commit - CalTrax production ready"
```

## **Step 2: Create GitHub Repository**
1. Go to https://github.com/new
2. Create a new repository: `caltrax-ai`
3. Don't initialize with README (we already have files)

## **Step 3: Connect to GitHub**
```bash
git remote add origin https://github.com/YOUR_USERNAME/caltrax-ai.git
git branch -M main
git push -u origin main
```

## **Step 4: Connect to Netlify**
1. Go to https://app.netlify.com
2. Click **"New site from Git"**
3. Choose **GitHub**
4. Select your `caltrax-ai` repository
5. Set build settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `.next`
6. Click **"Deploy site"**

## **Step 5: Set Environment Variables**
1. Go to **Site Settings** → **Environment Variables**
2. Add all your environment variables
3. Redeploy

## **Benefits of Git Deployment:**
- ✅ Automatic deployments on code changes
- ✅ Version control
- ✅ Easy rollbacks
- ✅ No file size limits
- ✅ More reliable than ZIP uploads
