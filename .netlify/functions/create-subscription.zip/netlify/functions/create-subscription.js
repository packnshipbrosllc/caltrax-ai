var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/rate-limiter.js
var require_rate_limiter = __commonJS({
  "netlify/functions/rate-limiter.js"(exports2, module2) {
    var rateLimitMap = /* @__PURE__ */ new Map();
    var rateLimiter2 = (identifier, maxRequests = 10, windowMs = 6e4) => {
      const now = Date.now();
      const windowStart = now - windowMs;
      const requests = rateLimitMap.get(identifier) || [];
      const recentRequests = requests.filter((timestamp) => timestamp > windowStart);
      if (recentRequests.length >= maxRequests) {
        return false;
      }
      recentRequests.push(now);
      rateLimitMap.set(identifier, recentRequests);
      return true;
    };
    setInterval(() => {
      const now = Date.now();
      const oneHourAgo = now - 36e5;
      for (const [key, requests] of rateLimitMap.entries()) {
        const recentRequests = requests.filter((timestamp) => timestamp > oneHourAgo);
        if (recentRequests.length === 0) {
          rateLimitMap.delete(key);
        } else {
          rateLimitMap.set(key, recentRequests);
        }
      }
    }, 3e5);
    module2.exports = { rateLimiter: rateLimiter2 };
  }
});

// netlify/functions/create-subscription.js
var stripe = require("stripe")(process.env.STRIPESECRETKEY);
var { rateLimiter } = require_rate_limiter();
exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { customerId, paymentMethodId, planId, email } = JSON.parse(event.body);
    if (!customerId || !paymentMethodId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Customer ID and Payment Method ID are required" })
      };
    }
    const clientIP = event.headers["x-forwarded-for"] || event.headers["client-ip"] || "unknown";
    if (!rateLimiter(`create-subscription-${clientIP}`, 3, 6e4)) {
      return {
        statusCode: 429,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Retry-After": "60"
        },
        body: JSON.stringify({
          error: "Too many subscription attempts. Please try again in 1 minute.",
          retryAfter: 60
        })
      };
    }
    await stripe.paymentMethods.attach(paymentMethodId, {
      customer: customerId
    });
    await stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId
      }
    });
    const priceIdMap = {
      "trial": "price_1S84cT2LmuiKVnPd3NXruhvk",
      // Monthly price for trial
      "monthly": "price_1S84cT2LmuiKVnPd3NXruhvk",
      "yearly": "price_1S84dS2LmuiKVnPdj6UCRzsN"
    };
    const actualPriceId = priceIdMap[planId] || planId;
    const trialDays = 3;
    console.log("Creating subscription with:", { customerId, actualPriceId, trialDays });
    const subscriptionData = {
      customer: customerId,
      items: [{ price: actualPriceId }],
      trial_period_days: trialDays,
      payment_behavior: "allow_incomplete",
      payment_settings: {
        save_default_payment_method: "on_subscription"
      },
      expand: ["latest_invoice.payment_intent"]
    };
    console.log("Subscription data being sent to Stripe:", subscriptionData);
    const subscription = await stripe.subscriptions.create(subscriptionData);
    console.log("\u2705 Subscription created successfully:", {
      id: subscription.id,
      status: subscription.status,
      customer: subscription.customer,
      trial_end: subscription.trial_end,
      current_period_end: subscription.current_period_end
    });
    let clientSecret = null;
    if (subscription.latest_invoice && subscription.latest_invoice.payment_intent) {
      clientSecret = subscription.latest_invoice.payment_intent.client_secret;
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: JSON.stringify({
        subscriptionId: subscription.id,
        clientSecret,
        status: subscription.status,
        trialEnd: subscription.trial_end,
        currentPeriodEnd: subscription.current_period_end,
        debug: {
          hasLatestInvoice: !!subscription.latest_invoice,
          hasPaymentIntent: !!(subscription.latest_invoice && subscription.latest_invoice.payment_intent),
          subscriptionStatus: subscription.status
        }
      })
    };
  } catch (error) {
    console.error("Error creating subscription:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: "Failed to create subscription",
        details: error.message
      })
    };
  }
};
