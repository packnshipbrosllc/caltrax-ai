// netlify/functions/debug-env.js
exports.handler = async (event, context) => {
  const stripeVars = Object.keys(process.env).filter(
    (key) => key.includes("STRIPE") || key.includes("REACT")
  );
  const envData = {};
  stripeVars.forEach((key) => {
    envData[key] = process.env[key] ? "EXISTS" : "MISSING";
  });
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({
      message: "Environment variables debug",
      foundVars: stripeVars,
      envData,
      allEnvKeys: Object.keys(process.env).filter(
        (key) => key.includes("STRIPE") || key.includes("REACT") || key.includes("NETLIFY")
      )
    })
  };
};
