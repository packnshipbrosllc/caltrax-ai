var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/rate-limiter.js
var require_rate_limiter = __commonJS({
  "netlify/functions/rate-limiter.js"(exports2, module2) {
    var rateLimitMap = /* @__PURE__ */ new Map();
    var rateLimiter2 = (identifier, maxRequests = 10, windowMs = 6e4) => {
      const now = Date.now();
      const windowStart = now - windowMs;
      const requests = rateLimitMap.get(identifier) || [];
      const recentRequests = requests.filter((timestamp) => timestamp > windowStart);
      if (recentRequests.length >= maxRequests) {
        return false;
      }
      recentRequests.push(now);
      rateLimitMap.set(identifier, recentRequests);
      return true;
    };
    setInterval(() => {
      const now = Date.now();
      const oneHourAgo = now - 36e5;
      for (const [key, requests] of rateLimitMap.entries()) {
        const recentRequests = requests.filter((timestamp) => timestamp > oneHourAgo);
        if (recentRequests.length === 0) {
          rateLimitMap.delete(key);
        } else {
          rateLimitMap.set(key, recentRequests);
        }
      }
    }, 3e5);
    module2.exports = { rateLimiter: rateLimiter2 };
  }
});

// netlify/functions/create-customer.js
var stripe = require("stripe")(process.env.STRIPESECRETKEY);
var { rateLimiter } = require_rate_limiter();
exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { email, name } = JSON.parse(event.body);
    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Email is required" })
      };
    }
    const clientIP = event.headers["x-forwarded-for"] || event.headers["client-ip"] || "unknown";
    if (!rateLimiter(`create-customer-${clientIP}`, 5, 6e4)) {
      return {
        statusCode: 429,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Retry-After": "60"
        },
        body: JSON.stringify({
          error: "Too many requests. Please try again in 1 minute.",
          retryAfter: 60
        })
      };
    }
    const customer = await stripe.customers.create({
      email,
      name: name || email.split("@")[0],
      metadata: {
        source: "caltrax-ai"
      }
    });
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: JSON.stringify({
        customerId: customer.id,
        email: customer.email
      })
    };
  } catch (error) {
    console.error("Error creating customer:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: "Failed to create customer",
        details: error.message
      })
    };
  }
};
