// netlify/functions/rate-limiter.js
var rateLimitMap = /* @__PURE__ */ new Map();
var rateLimiter = (identifier, maxRequests = 10, windowMs = 6e4) => {
  const now = Date.now();
  const windowStart = now - windowMs;
  const requests = rateLimitMap.get(identifier) || [];
  const recentRequests = requests.filter((timestamp) => timestamp > windowStart);
  if (recentRequests.length >= maxRequests) {
    return false;
  }
  recentRequests.push(now);
  rateLimitMap.set(identifier, recentRequests);
  return true;
};
setInterval(() => {
  const now = Date.now();
  const oneHourAgo = now - 36e5;
  for (const [key, requests] of rateLimitMap.entries()) {
    const recentRequests = requests.filter((timestamp) => timestamp > oneHourAgo);
    if (recentRequests.length === 0) {
      rateLimitMap.delete(key);
    } else {
      rateLimitMap.set(key, recentRequests);
    }
  }
}, 3e5);
module.exports = { rateLimiter };
